/* ÓRBITA — anúncio 9:16 (1080x1920)
 * Renderizador determinístico em Canvas 2D: renderFrame(t) desenha o quadro do instante t (s).
 * Todos os tempos vêm de timeline.js (compartilhado com audio.py).
 */
(function () {
  'use strict';
  const W = 1080, H = 1920, TAU = Math.PI * 2;
  const TL = window.TL;
  const COL = { bg: '#06070C', ink: '#EFE8DA', sig: '#FF5B24', cool: '#8FD8FF', strip: '#15110E' };

  // ---------- utilidades ----------
  const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
  const lerp = (a, b, t) => a + (b - a) * t;
  const prog = (t, a, b) => clamp((t - a) / (b - a));
  const E = {
    outCubic: x => 1 - Math.pow(1 - x, 3),
    inCubic: x => x * x * x,
    inOutCubic: x => x < .5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2,
    outQuart: x => 1 - Math.pow(1 - x, 4),
    outExpo: x => x >= 1 ? 1 : 1 - Math.pow(2, -10 * x),
    inExpo: x => x <= 0 ? 0 : Math.pow(2, 10 * x - 10),
    inOutExpo: x => x <= 0 ? 0 : x >= 1 ? 1 : x < .5 ? Math.pow(2, 20 * x - 10) / 2 : (2 - Math.pow(2, -20 * x + 10)) / 2,
    outBack: x => { const c1 = 1.9, c3 = c1 + 1; return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2); },
    inOutSine: x => -(Math.cos(Math.PI * x) - 1) / 2,
  };
  function rng(seed) {
    return function () {
      seed |= 0; seed = seed + 0x6D2B79F5 | 0;
      let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  const hash = n => rng(Math.floor(n) * 9973 + 17)();
  function rgba(hex, a) {
    const n = parseInt(hex.slice(1), 16);
    return `rgba(${n >> 16 & 255},${n >> 8 & 255},${n & 255},${a})`;
  }
  function glow(ctx, x, y, r, hex, a) {
    if (r <= 0 || a <= 0) return;
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, rgba(hex, a));
    g.addColorStop(0.35, rgba(hex, a * 0.35));
    g.addColorStop(1, rgba(hex, 0));
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
  }
  function rrect(ctx, x, y, w, h, r) {
    r = Math.max(0, Math.min(r, w / 2, h / 2));
    ctx.beginPath(); ctx.roundRect(x, y, w, h, r);
  }
  function ellPt(cx, cy, rx, ry, rot, a) {
    const c = Math.cos(rot), s = Math.sin(rot), x = rx * Math.cos(a), y = ry * Math.sin(a);
    return [cx + x * c - y * s, cy + x * s + y * c];
  }
  // caminhos de órbita separados em metade traseira (sin<0) e dianteira
  function orbitPaths(cx, cy, rx, ry, rot, a0, p) {
    const back = new Path2D(), front = new Path2D();
    const N = 220, span = TAU * clamp(p);
    let prev = null;
    for (let i = 0; i <= N; i++) {
      const a = a0 + span * i / N;
      const pt = ellPt(cx, cy, rx, ry, rot, a);
      if (prev) {
        const path = Math.sin(a) < 0 ? back : front;
        path.moveTo(prev[0], prev[1]); path.lineTo(pt[0], pt[1]);
      }
      prev = pt;
    }
    return { back, front };
  }

  // ---------- estrelas ----------
  const STARS = (() => {
    const r = rng(7), a = [];
    for (let i = 0; i < 1100; i++) {
      const k = r();
      a.push({ x: r() * 2 - 1, y: r() * 2 - 1, z: r(), s: r(), p: r() * TAU, c: k < 0.08 ? COL.sig : k < 0.22 ? COL.cool : COL.ink });
    }
    return a;
  })();
  function drawStars(ctx, t, cx, cy, sx, sy, alpha = 1, zoom = 0, scale = 1) {
    if (alpha <= 0) return;
    for (const st of STARS) {
      const f = 1 + zoom * (0.3 + st.z);
      const x = cx + st.x * sx * f, y = cy + st.y * sy * f;
      const tw = 0.55 + 0.45 * Math.sin(t * (2 + st.z * 3) + st.p);
      const a = alpha * tw * (0.25 + 0.75 * st.s * st.s);
      const r = (0.5 + Math.pow(st.s, 4) * 2.4) * scale;
      ctx.fillStyle = rgba(st.c, a);
      if (r < 1.1) ctx.fillRect(x - r, y - r, r * 2, r * 2);
      else { ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); if (st.s > 0.93) glow(ctx, x, y, r * 6, st.c, a * 0.35); }
    }
  }

  // ---------- planeta ----------
  function drawPlanet(ctx, cx, cy, R, t, glowAmt = 1) {
    if (R <= 0.5) return;
    glow(ctx, cx + R * 0.15, cy - R * 0.15, R * 1.75, COL.sig, 0.32 * glowAmt);
    ctx.save();
    ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.clip();
    ctx.fillStyle = '#0A0B12'; ctx.fillRect(cx - R, cy - R, 2 * R, 2 * R);
    const lx = cx + R * 0.55, ly = cy - R * 0.6;
    let g = ctx.createRadialGradient(lx, ly, 0, lx, ly, R * 1.95);
    g.addColorStop(0, '#FFE9D2'); g.addColorStop(0.16, '#FF9A5C'); g.addColorStop(0.4, '#D2420F');
    g.addColorStop(0.68, 'rgba(70,16,8,0.75)'); g.addColorStop(1, 'rgba(10,11,18,0)');
    ctx.fillStyle = g; ctx.fillRect(cx - R, cy - R, 2 * R, 2 * R);
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(-0.22);
    for (let k = -7; k <= 7; k++) {
      const y = k * R * 0.13 + Math.sin(k * 2.1 + t * 0.6) * R * 0.02;
      ctx.fillStyle = k % 2 ? 'rgba(20,6,4,0.16)' : 'rgba(255,220,190,0.05)';
      ctx.fillRect(-R, y, 2 * R, R * (0.035 + 0.03 * hash(k + 40)));
    }
    ctx.restore();
    g = ctx.createRadialGradient(cx - R * 0.85, cy + R * 0.85, 0, cx - R * 0.85, cy + R * 0.85, R * 1.1);
    g.addColorStop(0, 'rgba(143,216,255,0.22)'); g.addColorStop(1, 'rgba(143,216,255,0)');
    ctx.fillStyle = g; ctx.fillRect(cx - R, cy - R, 2 * R, 2 * R);
    ctx.restore();
    ctx.strokeStyle = 'rgba(255,190,150,0.55)'; ctx.lineWidth = Math.max(1, R * 0.012);
    ctx.beginPath(); ctx.arc(cx, cy, R, -Math.PI * 0.95, Math.PI * 0.05); ctx.stroke();
  }

  // ---------- mundo de abertura (planeta + órbita + satélite) ----------
  const WORLD = { R: 170, rx: 340, ry: 92, rot: -0.21, a0: 2.4 };
  function satAngleA(t) {
    const d = t - 0.35;
    return WORLD.a0 + 3.2 * d + 3.0 * (1 - Math.exp(-3 * d));
  }
  function drawWorld(ctx, t, cx, cy, s) {
    drawStars(ctx, t, cx, cy, 640 * s, 1320 * s, 1, 0, Math.max(0.6, s));
    const appear = E.outExpo(prog(t, 0.25, 1.5));
    const seed = 1 - prog(t, 0.0, 0.6);
    const ig = prog(t, 0.0, 0.12) * (1 - prog(t, 0.6, 1.2));
    if (ig > 0) { glow(ctx, cx, cy, 160 * s * (0.6 + seed), '#FFE9D2', 0.9 * ig); ctx.fillStyle = rgba('#FFFFFF', ig); ctx.beginPath(); ctx.arc(cx, cy, 4 * s, 0, TAU); ctx.fill(); }
    const R = WORLD.R * s * appear;
    const rx = WORLD.rx * s, ry = WORLD.ry * s;
    const d = t - 0.35;
    const sa = satAngleA(t);
    const p = d <= 0 ? 0 : clamp((sa - WORLD.a0) / TAU);
    const paths = orbitPaths(cx, cy, rx, ry, WORLD.rot, WORLD.a0, p);
    ctx.lineWidth = 2 * Math.max(s, 0.7);
    ctx.strokeStyle = rgba(COL.ink, 0.28); ctx.stroke(paths.back);
    const satPt = ellPt(cx, cy, rx, ry, WORLD.rot, sa);
    const satBack = Math.sin(sa) < 0;
    const drawSat = () => {
      if (d <= 0) return;
      const sr = 9 * s * (satBack ? 0.8 : 1.1);
      glow(ctx, satPt[0], satPt[1], sr * 7, COL.sig, 0.6);
      ctx.fillStyle = '#FFD2B8'; ctx.beginPath(); ctx.arc(satPt[0], satPt[1], sr, 0, TAU); ctx.fill();
    };
    if (satBack) drawSat();
    drawPlanet(ctx, cx, cy, R, t, appear);
    ctx.strokeStyle = rgba(COL.ink, 0.75); ctx.stroke(paths.front);
    if (!satBack) drawSat();
  }

  // ---------- vinhetas (cada quadro da película é um mundo) ----------
  function vWorld(ctx, w, h, t) {
    ctx.fillStyle = COL.bg; ctx.fillRect(0, 0, w, h);
    drawWorld(ctx, t, w / 2, h / 2, 0.72);
  }
  function rings(ctx, cx, cy, rx, ry, rot, half) {
    const a0 = half === 'back' ? Math.PI : 0, a1 = a0 + Math.PI;
    const spec = [[0.74, 3, 0.25], [0.8, 9, 0.45], [0.87, 5, 0.7], [0.92, 2, 0.35], [0.97, 7, 0.55], [1.03, 2, 0.3]];
    for (const [k, lw, a] of spec) {
      ctx.strokeStyle = rgba('#F3DCC0', a * (half === 'back' ? 0.6 : 1));
      ctx.lineWidth = lw;
      ctx.beginPath(); ctx.ellipse(cx, cy, rx * k, ry * k, rot, a0, a1); ctx.stroke();
    }
  }
  function vRing(ctx, w, h, t) {
    const g0 = ctx.createLinearGradient(0, 0, 0, h); g0.addColorStop(0, '#070912'); g0.addColorStop(1, '#120B12');
    ctx.fillStyle = g0; ctx.fillRect(0, 0, w, h);
    drawStars(ctx, t, w / 2, h / 2, w * 0.6, h * 0.7, 0.7);
    const cx = w * 0.5, cy = h * 0.53, R = 124, rot = -0.3, rx = 300, ry = 62;
    rings(ctx, cx, cy, rx, ry, rot, 'back');
    ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.clip();
    ctx.translate(cx, cy); ctx.rotate(rot);
    const pal = ['#E9C9A0', '#D98A55', '#B5532B', '#F0DCC0', '#8E3B22', '#E8A36E'];
    for (let k = -11; k <= 11; k++) {
      const y = k * R * 0.095;
      ctx.fillStyle = pal[(k + 22) % pal.length];
      ctx.fillRect(-R, y, 2 * R, R * 0.1);
      ctx.fillStyle = 'rgba(255,240,220,0.12)';
      const off = ((t * 40 * (1 + (Math.abs(k) % 3) * 0.3)) % (2 * R)) - R;
      ctx.fillRect(off - 30, y + R * 0.03, 60, R * 0.02);
    }
    const g = ctx.createRadialGradient(R * 0.45, -R * 0.55, 0, R * 0.45, -R * 0.55, R * 2.1);
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(0.45, 'rgba(0,0,0,0.18)'); g.addColorStop(0.78, 'rgba(4,4,10,0.88)'); g.addColorStop(1, 'rgba(4,4,10,0.97)');
    ctx.fillStyle = g; ctx.fillRect(-R * 2, -R * 2, R * 4, R * 4);
    ctx.restore();
    rings(ctx, cx, cy, rx, ry, rot, 'front');
    glow(ctx, cx + R * 0.5, cy - R * 0.6, R * 0.8, '#FFE9D2', 0.12);
  }
  function vEclipse(ctx, w, h, t) {
    ctx.fillStyle = '#030306'; ctx.fillRect(0, 0, w, h);
    drawStars(ctx, t, w / 2, h / 2, w * 0.6, h * 0.7, 0.55);
    const cx = w / 2, cy = h / 2, R = 112;
    let g = ctx.createRadialGradient(cx, cy, R * 0.9, cx, cy, R * 2.7);
    g.addColorStop(0, 'rgba(255,244,228,0.98)'); g.addColorStop(0.07, 'rgba(255,205,160,0.6)');
    g.addColorStop(0.3, 'rgba(255,91,36,0.22)'); g.addColorStop(1, 'rgba(255,91,36,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, R * 2.7, 0, TAU); ctx.fill();
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    const r = rng(33);
    for (let i = 0; i < 110; i++) {
      const a = r() * TAU, base = r(), ph = r() * TAU;
      const len = R * (1.15 + base * 0.9 * (0.65 + 0.35 * Math.sin(t * 2.3 + ph)));
      ctx.strokeStyle = 'rgba(255,' + (200 + Math.floor(base * 50)) + ',' + (170 + Math.floor(base * 60)) + ',' + (0.05 + base * 0.12) + ')';
      ctx.lineWidth = 1 + base * 1.5;
      ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * R, cy + Math.sin(a) * R); ctx.lineTo(cx + Math.cos(a) * len, cy + Math.sin(a) * len); ctx.stroke();
    }
    ctx.restore();
    const ox = Math.sin(t * 0.9) * 8;
    ctx.fillStyle = '#020203'; ctx.beginPath(); ctx.arc(cx + ox, cy, R, 0, TAU); ctx.fill();
    const da = -0.75, dx = cx + ox * 0.2 + Math.cos(da) * R, dy = cy + Math.sin(da) * R;
    const fl = 0.85 + 0.15 * Math.sin(t * 11);
    glow(ctx, dx, dy, 70 * fl, '#FFFFFF', 0.95);
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    g = ctx.createLinearGradient(dx - 260, dy, dx + 260, dy);
    g.addColorStop(0, 'rgba(255,240,220,0)'); g.addColorStop(0.5, 'rgba(255,240,220,0.8)'); g.addColorStop(1, 'rgba(255,240,220,0)');
    ctx.fillStyle = g; ctx.fillRect(dx - 260, dy - 1.5, 520, 3);
    ctx.restore();
  }
  function vTunnel(ctx, w, h, t) {
    ctx.fillStyle = '#05060B'; ctx.fillRect(0, 0, w, h);
    const vx = w / 2 + Math.sin(t * 1.3) * 34, vy = h / 2 + Math.cos(t * 1.1) * 22;
    glow(ctx, vx, vy, 160, '#FFE9D2', 0.55);
    ctx.strokeStyle = 'rgba(239,232,218,0.08)'; ctx.lineWidth = 1;
    for (let i = 0; i < 12; i++) { const a = i * TAU / 12 + t * 0.2; ctx.beginPath(); ctx.moveTo(vx, vy); ctx.lineTo(vx + Math.cos(a) * 900, vy + Math.sin(a) * 900); ctx.stroke(); }
    const N = 30, phase = (t * 1.6) % 1;
    for (let k = N - 1; k >= 0; k--) {
      const d = (k + 1 - phase) / N;
      const r = 26 / (d + 0.02);
      if (r > 1400) continue;
      const idx = k + Math.floor(t * 1.6);
      const twist = idx * 0.16 + t * 0.4;
      const near = 1 - d;
      const cxk = lerp(w / 2, vx, d), cyk = lerp(h / 2, vy, d);
      ctx.strokeStyle = idx % 5 === 0 ? rgba(COL.sig, 0.25 + near * 0.75) : rgba(COL.ink, 0.06 + near * 0.6);
      ctx.lineWidth = 0.6 + near * near * 5;
      ctx.beginPath();
      for (let j = 0; j <= 6; j++) {
        const a = twist + j * TAU / 6;
        const x = cxk + Math.cos(a) * r, y = cyk + Math.sin(a) * r * 0.82;
        if (j) ctx.lineTo(x, y); else ctx.moveTo(x, y);
      }
      ctx.stroke();
    }
  }
  function ridge(x, base, amp, seed) {
    return base - amp * (0.55 * Math.sin(x * 0.011 + seed) + 0.3 * Math.sin(x * 0.027 + seed * 2.3) + 0.15 * Math.sin(x * 0.071 + seed * 4.1));
  }
  function vSuns(ctx, w, h, t) {
    const g = ctx.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, '#0A0D1F'); g.addColorStop(0.45, '#2B1630'); g.addColorStop(0.72, '#9C3A1E'); g.addColorStop(0.82, '#FF7A3D'); g.addColorStop(1, '#FFB27A');
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    ctx.save(); ctx.beginPath(); ctx.rect(0, 0, w, h * 0.45); ctx.clip();
    drawStars(ctx, t, w / 2, h * 0.3, w * 0.6, h * 0.4, 0.6); ctx.restore();
    const s1y = h * 0.66 + (t - 6.1) * 14, s2y = h * 0.55 + (t - 6.1) * 9;
    glow(ctx, w * 0.36, s1y, 260, '#FFD9B0', 0.6);
    ctx.fillStyle = '#FFF2E0'; ctx.beginPath(); ctx.arc(w * 0.36, s1y, 60, 0, TAU); ctx.fill();
    glow(ctx, w * 0.63, s2y, 120, COL.sig, 0.8);
    ctx.fillStyle = '#FF6A30'; ctx.beginPath(); ctx.arc(w * 0.63, s2y, 23, 0, TAU); ctx.fill();
    const layer = (base, amp, seed, col) => {
      ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(0, h);
      for (let x = 0; x <= w; x += 6) ctx.lineTo(x, ridge(x, base, amp, seed));
      ctx.lineTo(w, h); ctx.closePath(); ctx.fill();
    };
    layer(h * 0.76, 34, 1.7, '#4A1E24');
    layer(h * 0.86, 46, 4.2, '#0A0709');
    const fx = w * 0.71, fy = ridge(fx, h * 0.86, 46, 4.2);
    ctx.fillStyle = '#0A0709';
    ctx.beginPath(); ctx.arc(fx, fy - 30, 5.5, 0, TAU); ctx.fill();
    rrect(ctx, fx - 5, fy - 24, 10, 26, 4); ctx.fill();
  }
  const SHIP = [[0, 0], [120, -20], [250, -28], [292, -62], [326, -62], [318, -27], [384, -22], [384, 22], [318, 27], [326, 54], [292, 54], [250, 26], [120, 18]];
  function vShip(ctx, w, h, t) {
    const g = ctx.createLinearGradient(0, 0, w, h); g.addColorStop(0, '#04050A'); g.addColorStop(1, '#0A0E1A');
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    const r = rng(91);
    for (let i = 0; i < 160; i++) {
      const z = r(), y = r() * h, x0 = r() * (w + 300);
      const x = ((x0 - t * 380 * (0.2 + z)) % (w + 300) + (w + 300)) % (w + 300) - 150;
      ctx.strokeStyle = rgba(z > 0.9 ? COL.cool : COL.ink, 0.15 + z * 0.55); ctx.lineWidth = 0.8 + z * 1.4;
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 10 + z * 110, y); ctx.stroke();
    }
    const pcx = w * 0.88, pcy = h * 1.75, pr = h * 1.1;
    glow(ctx, pcx, pcy - pr, 260, COL.cool, 0.18);
    ctx.fillStyle = '#05070D'; ctx.beginPath(); ctx.arc(pcx, pcy, pr, 0, TAU); ctx.fill();
    ctx.strokeStyle = rgba(COL.cool, 0.6); ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(pcx, pcy, pr, 0, TAU); ctx.stroke();
    const sx = w * 0.25 - (t - 6.37) * 170, sy = h * 0.44;
    ctx.save(); ctx.translate(sx, sy); ctx.rotate(-0.06);
    const fl = 0.8 + 0.2 * Math.sin(t * 40);
    glow(ctx, 392, 0, 120 * fl, COL.sig, 0.9);
    glow(ctx, 392, 0, 40, '#FFF1DE', 1);
    ctx.beginPath(); SHIP.forEach(([x, y], i) => { if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); }); ctx.closePath();
    ctx.fillStyle = '#0B0C12'; ctx.fill();
    ctx.strokeStyle = 'rgba(239,232,218,0.55)'; ctx.lineWidth = 1.6; ctx.stroke();
    ctx.fillStyle = 'rgba(255,220,180,0.9)';
    for (let i = 0; i < 9; i++) ctx.fillRect(140 + i * 18, -8, 6, 3);
    ctx.fillStyle = rgba(COL.cool, 0.9); ctx.fillRect(28, -5, 18, 4);
    ctx.restore();
  }
  function vEye(ctx, w, h, t) {
    ctx.fillStyle = '#060509'; ctx.fillRect(0, 0, w, h);
    const cx = w / 2, cy = h / 2;
    ctx.strokeStyle = 'rgba(239,232,218,0.2)'; ctx.lineWidth = 1.5;
    for (const r of [232, 218, 168]) { ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.stroke(); }
    for (let i = 0; i < 90; i++) {
      const a = i * TAU / 90 + t * 0.35, long = i % 6 === 0;
      ctx.strokeStyle = long ? rgba(COL.sig, 0.9) : 'rgba(239,232,218,0.35)'; ctx.lineWidth = long ? 3 : 1.5;
      const r0 = 190, r1 = long ? 214 : 202;
      ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0); ctx.lineTo(cx + Math.cos(a) * r1, cy + Math.sin(a) * r1); ctx.stroke();
    }
    const R = 150;
    let g = ctx.createRadialGradient(cx, cy, 0, cx, cy, R);
    g.addColorStop(0, '#FFE1C4'); g.addColorStop(0.18, '#FF5B24'); g.addColorStop(0.6, '#5A1606'); g.addColorStop(1, '#140503');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.fill();
    const ap = 34 + 22 * (0.5 + 0.5 * Math.sin(t * 5.2));
    const n = 7, rot = t * 0.7;
    ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.clip();
    for (let i = 0; i < n; i++) {
      const a = rot + i * TAU / n, b = a + TAU / n;
      const p = (rr, an) => [cx + Math.cos(an) * rr, cy + Math.sin(an) * rr];
      const pts = [p(ap, a), p(R + 10, a - 0.55), p(R + 10, b + 0.2), p(ap, b)];
      ctx.beginPath(); pts.forEach((q, j) => { if (j) ctx.lineTo(q[0], q[1]); else ctx.moveTo(q[0], q[1]); }); ctx.closePath();
      ctx.fillStyle = 'rgba(14,10,12,0.93)'; ctx.fill();
      ctx.strokeStyle = 'rgba(239,232,218,0.3)'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]); ctx.lineTo(pts[1][0], pts[1][1]); ctx.stroke();
    }
    ctx.restore();
    glow(ctx, cx, cy, ap * 1.3, '#FFF1DE', 0.75);
    const sy = cy + Math.sin(t * 3.4) * 150;
    const hw = Math.sqrt(Math.max(0, 232 * 232 - (sy - cy) * (sy - cy)));
    g = ctx.createLinearGradient(cx - hw, 0, cx + hw, 0);
    g.addColorStop(0, 'rgba(143,216,255,0)'); g.addColorStop(0.5, 'rgba(143,216,255,0.6)'); g.addColorStop(1, 'rgba(143,216,255,0)');
    ctx.fillStyle = g; ctx.fillRect(cx - hw, sy - 1, hw * 2, 2);
  }
  function vGlobe(ctx, w, h, t) {
    ctx.fillStyle = '#04070C'; ctx.fillRect(0, 0, w, h);
    drawStars(ctx, t, w / 2, h / 2, w * 0.6, h * 0.7, 0.45);
    const cx = w / 2, cy = h / 2, R = 172, ry = t * 0.9, tilt = 0.42;
    glow(ctx, cx, cy, R * 1.6, COL.cool, 0.16);
    const proj = (lat, lon) => {
      const x = Math.cos(lat) * Math.sin(lon + ry), y = Math.sin(lat), z = Math.cos(lat) * Math.cos(lon + ry);
      const y2 = y * Math.cos(tilt) - z * Math.sin(tilt), z2 = y * Math.sin(tilt) + z * Math.cos(tilt);
      return [cx + R * x, cy - R * y2, z2];
    };
    const line = (fn) => {
      const pts = []; for (let i = 0; i <= 64; i++) pts.push(fn(i / 64));
      for (let i = 1; i < pts.length; i++) {
        const front = (pts[i][2] + pts[i - 1][2]) / 2 > 0;
        ctx.strokeStyle = front ? rgba(COL.cool, 0.85) : rgba(COL.cool, 0.13);
        ctx.lineWidth = front ? 1.8 : 1;
        ctx.beginPath(); ctx.moveTo(pts[i - 1][0], pts[i - 1][1]); ctx.lineTo(pts[i][0], pts[i][1]); ctx.stroke();
      }
    };
    for (let k = 0; k < 12; k++) line(u => proj(-Math.PI / 2 + Math.PI * u, k * TAU / 12));
    for (let k = 1; k < 8; k++) line(u => proj(-Math.PI / 2 + Math.PI * k / 8, TAU * u));
    ctx.strokeStyle = rgba(COL.cool, 0.7); ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.stroke();
    const a = t * 2.2, pt = ellPt(cx, cy, 270, 70, -0.25, a);
    ctx.strokeStyle = rgba(COL.ink, 0.25); ctx.lineWidth = 1.2; ctx.beginPath(); ctx.ellipse(cx, cy, 270, 70, -0.25, 0, TAU); ctx.stroke();
    glow(ctx, pt[0], pt[1], 40, COL.sig, 0.8);
    ctx.fillStyle = '#FFD2B8'; ctx.beginPath(); ctx.arc(pt[0], pt[1], 6, 0, TAU); ctx.fill();
  }
  const VIGNETTES = [vWorld, vRing, vEclipse, vTunnel, vSuns, vShip, vEye, vGlobe];

  // ---------- película 35 mm ----------
  const FW = 700, FH = 510, SW = 860, P = 560;
  function stripU(t) {
    let u = 0;
    for (const s of TL.snaps) u += E.outBack(prog(t, s, s + TL.snapDur));
    u += 11 * E.inCubic(prog(t, TL.rush[0], TL.rush[1]));
    return u;
  }
  function drawStrip(ctx, t, yc, u, alpha, c) {
    const x0 = W / 2 - SW / 2, fx = W / 2 - FW / 2;
    const top = -H, bot = 2 * H;
    if (alpha > 0) {
      ctx.save(); ctx.globalAlpha = alpha;
      const g = ctx.createLinearGradient(x0, 0, x0 + SW, 0);
      g.addColorStop(0, '#0E0B09'); g.addColorStop(0.03, '#1C1714'); g.addColorStop(0.5, '#15110E'); g.addColorStop(0.97, '#1C1714'); g.addColorStop(1, '#0E0B09');
      ctx.fillStyle = g; ctx.fillRect(x0, top, SW, bot - top);
      ctx.fillStyle = 'rgba(255,200,160,0.07)'; ctx.fillRect(x0, top, 2, bot - top); ctx.fillRect(x0 + SW - 2, top, 2, bot - top);
      const r = rng(5);
      for (let i = 0; i < 9; i++) { ctx.fillStyle = `rgba(255,235,210,${0.02 + r() * 0.04})`; ctx.fillRect(x0 + r() * SW, top, 1, bot - top); }
      const k0 = Math.floor((u - 3.5) * 4), k1 = Math.ceil((u + 3.5) * 4);
      for (let k = k0; k <= k1; k++) {
        const y = yc + (k / 4 - u) * P;
        ctx.fillStyle = '#040508';
        for (const hx of [x0 + 40, x0 + SW - 40]) { rrect(ctx, hx - 15, y - 20, 30, 40, 7); ctx.fill(); }
      }
      ctx.restore();
    }
    const i0 = Math.floor(u) - 3, i1 = Math.floor(u) + 3;
    for (let i = i0; i <= i1; i++) {
      const y = yc + (i - u) * P;
      if (i !== 0 && alpha <= 0) continue;
      let rx = fx, ry = y - FH / 2, rw = FW, rh = FH, rad = 12;
      ctx.save();
      if (i === 0 && c < 1) {
        rx = lerp(0, fx, c); ry = lerp(0, y - FH / 2, c); rw = lerp(W, FW, c); rh = lerp(H, FH, c); rad = lerp(0, 12, c);
        rrect(ctx, rx, ry, rw, rh, rad); ctx.clip();
        ctx.fillStyle = COL.bg; ctx.fillRect(rx, ry, rw, rh);
        drawWorld(ctx, t, W / 2, lerp(1240, y, c), lerp(1.04, 0.72, c));
      } else {
        ctx.globalAlpha = i === 0 ? 1 : alpha;
        rrect(ctx, rx, ry, rw, rh, rad); ctx.clip();
        ctx.translate(rx, ry);
        VIGNETTES[((i % 8) + 8) % 8](ctx, FW, FH, t);
        ctx.translate(-rx, -ry);
      }
      // quadros fora da janela do projetor ficam mais escuros; leve cintilação de 24 q/s
      const dist = Math.min(1, Math.abs(y - yc) / P);
      const flick = 0.035 * hash(Math.floor(t * 24) + i * 7);
      ctx.fillStyle = `rgba(4,4,7,${0.62 * dist + flick})`; ctx.fillRect(rx, ry, rw, rh);
      ctx.restore();
      if (c >= 1 || i !== 0) {
        ctx.save(); ctx.globalAlpha = i === 0 ? 1 : alpha;
        ctx.strokeStyle = 'rgba(239,232,218,0.14)'; ctx.lineWidth = 1.5; rrect(ctx, rx, ry, rw, rh, rad); ctx.stroke();
        if (i >= 0) {
          ctx.save(); ctx.translate(x0 + 24, y + FH / 2 - 10); ctx.rotate(-Math.PI / 2);
          ctx.font = '700 17px "Space Mono"'; ctx.letterSpacing = '3px'; ctx.textBaseline = 'middle';
          ctx.fillStyle = rgba(COL.sig, 0.85); ctx.fillText(`${TL.copy.brand} ▸ ${String(i + 1).padStart(3, '0')}`, 0, 0);
          ctx.restore();
          const rr = rng(i * 13 + 3); ctx.fillStyle = rgba(COL.ink, 0.35);
          for (let b = 0; b < 16; b++) { const bw = rr() < 0.5 ? 2 : 5; ctx.fillRect(x0 + SW - 30, y - FH / 2 + 24 + b * 9, 12, bw); }
        }
        ctx.restore();
      }
    }
  }

  // ---------- layout tipográfico ----------
  let LAY = null;
  function computeLayout() {
    const m = document.createElement('canvas').getContext('2d');
    const lines = TL.copy.headline;
    m.font = '700 100px Unbounded';
    const maxw = Math.max(...lines.map(s => m.measureText(s).width));
    const size = Math.min(160, Math.floor(100 * 880 / maxw));
    m.font = `700 ${size}px Unbounded`;
    const head = {
      size, x: 96,
      lines: lines.map((text, li) => ({
        text, y: 480 + li * size * 1.12, start: TL.headline.starts[li],
        color: li === lines.length - 1 ? COL.sig : COL.ink,
        chars: [...text], offs: [...text].map((_, ci) => m.measureText([...text].slice(0, ci).join('')).width)
      }))
    };
    // logotipo: "O" + "RBITA"; o acento agudo do Ó é o satélite
    const word = 'ORBITA';
    m.font = '800 100px Unbounded';
    const ls = Math.floor(100 * 900 / m.measureText(word).width);
    const font = `800 ${ls}px Unbounded`;
    m.font = font;
    const mo = m.measureText('O');
    const total = m.measureText(word).width;
    const x0 = W / 2 - total / 2;
    const offs = [...word].map((_, i) => m.measureText(word.slice(0, i)).width);
    const asc = mo.actualBoundingBoxAscent, desc = mo.actualBoundingBoxDescent;
    const cy = 870;
    const yB = cy + (asc - desc) / 2;
    const oL = x0 - mo.actualBoundingBoxLeft, oR = x0 + mo.actualBoundingBoxRight;
    const oCx = (oL + oR) / 2, oCy = yB - (asc - desc) / 2, capH = asc + desc;
    const acc = { x: oCx + capH * 0.09, y: yB - asc - capH * 0.27, w: capH * 0.135, h: capH * 0.34, rot: 0.72 };
    const ecx = W / 2, ecy = oCy, rot = 0.12;
    const dx = acc.x - ecx, dy = acc.y - ecy;
    const uu = dx * Math.cos(rot) + dy * Math.sin(rot), vv = -dx * Math.sin(rot) + dy * Math.cos(rot);
    const rx = Math.max(505, Math.abs(uu) * 1.3);
    const ry = Math.abs(vv) / Math.sqrt(1 - (uu / rx) ** 2);
    const aDock = Math.atan2(vv / ry, uu / rx);
    m.font = '500 56px "Space Grotesk"';
    const tag = TL.copy.tagline.map((s, i) => ({ text: s, w: m.measureText(s).width, y: yB + 205 + i * 72 }));
    m.font = '600 50px "Space Grotesk"';
    const ctaW = m.measureText(TL.copy.cta).width;
    LAY = { head, logo: { font, size: ls, x0, offs, word, yB, oL, oR, oCx, oCy, capH, asc, acc, ell: { cx: ecx, cy: ecy, rx, ry, rot }, aDock, tag, ctaW } };
    return LAY;
  }

  // ---------- título ----------
  function drawHeadline(ctx, t) {
    const L = LAY.head, s = L.size;
    ctx.font = `700 ${s}px Unbounded`; ctx.textBaseline = 'alphabetic'; ctx.textAlign = 'left';
    L.lines.forEach((ln, li) => {
      const ex0 = TL.headline.exit + li * 0.06;
      const exitP = E.inCubic(prog(t, ex0, ex0 + 0.38));
      if (exitP >= 1 || t < ln.start) return;
      ctx.save();
      ctx.beginPath(); ctx.rect(0, ln.y - s * 0.98, W, s * 1.22); ctx.clip();
      ln.chars.forEach((ch, ci) => {
        const st = ln.start + ci * TL.headline.stagger;
        const p = E.outExpo(prog(t, st, st + TL.headline.charDur));
        if (p <= 0) return;
        const dy = (1 - p) * s * 1.05 - exitP * s * 1.25;
        ctx.fillStyle = ln.color;
        ctx.fillText(ch, L.x + ln.offs[ci], ln.y + dy);
      });
      ctx.restore();
    });
    const k = prog(t, 3.0, 3.5) * (1 - prog(t, 3.5, 4.2));
    if (k > 0) glow(ctx, L.x + 220, L.lines[2].y - s * 0.35, 420, COL.sig, 0.14 * k);
  }
  function drawHUD(ctx, t) {
    const a = prog(t, 0.2, 0.6) * (1 - prog(t, 7.6, 7.9));
    if (a <= 0) return;
    ctx.save(); ctx.globalAlpha = a;
    ctx.font = '700 26px "Space Mono"'; ctx.letterSpacing = '8px'; ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
    ctx.fillStyle = COL.sig; ctx.beginPath(); ctx.arc(104, 250, 7, 0, TAU); ctx.fill();
    ctx.fillStyle = rgba(COL.ink, 0.8); ctx.fillText(TL.copy.brand, 126, 251);
    const f = Math.floor(t * 24), ss = Math.floor(f / 24), ff = f % 24;
    ctx.font = '400 24px "Space Mono"'; ctx.letterSpacing = '4px'; ctx.textAlign = 'right';
    ctx.fillStyle = rgba(COL.ink, 0.55);
    ctx.fillText(`00:00:${String(ss).padStart(2, '0')}:${String(ff).padStart(2, '0')}`, W - 92, 251);
    ctx.restore();
  }

  // ---------- fase A: abertura + película ----------
  function phaseA(ctx, t) {
    ctx.fillStyle = COL.bg; ctx.fillRect(0, 0, W, H);
    const c = E.inOutExpo(prog(t, TL.contract[0], TL.contract[1]));
    const rec = E.inOutCubic(prog(t, TL.recenter[0], TL.recenter[1]));
    const yc = lerp(1245, 960, rec);
    if (t < TL.contract[0]) {
      drawWorld(ctx, t, W / 2, 1240, 1 + 0.04 * t / 2);
    } else {
      drawStars(ctx, t, W / 2, H / 2, W * 0.75, H * 0.62, 0.5 * c, 0.15 * prog(t, 6, 8));
      const u = stripU(t);
      const stripA = E.outCubic(prog(t, 2.35, 3.1));
      const rot = -0.075 * E.inOutCubic(prog(t, 5.9, 6.4));
      const zoom = 1 + 0.08 * E.inOutCubic(prog(t, 5.9, 6.4)) + 0.35 * E.inExpo(prog(t, TL.rush[0], TL.rush[1]));
      glow(ctx, W / 2, yc, 760, '#FFB27A', 0.10 * stripA);
      ctx.save();
      const wv = c >= 1 ? 1 : 0;
      ctx.translate(W / 2 + wv * (hash(t * 30) - 0.5) * 2.4, yc + wv * (hash(t * 30 + 5) - 0.5) * 2.4);
      ctx.rotate(rot); ctx.scale(zoom, zoom); ctx.translate(-W / 2, -yc);
      drawStrip(ctx, t, yc, u, stripA, c);
      ctx.restore();
      const veil = stripA * (1 - prog(t, 4.0, 4.5));
      if (veil > 0) {
        const g = ctx.createLinearGradient(0, 0, 0, 1000);
        g.addColorStop(0, rgba(COL.bg, 0.92 * veil)); g.addColorStop(0.78, rgba(COL.bg, 0.8 * veil)); g.addColorStop(1, rgba(COL.bg, 0));
        ctx.fillStyle = g; ctx.fillRect(0, 0, W, 1000);
      }
      const wh = E.inExpo(prog(t, 7.7, 8.0));
      if (wh > 0) { ctx.fillStyle = `rgba(255,236,214,${0.85 * wh})`; ctx.fillRect(0, 0, W, H); }
    }
    drawHeadline(ctx, t);
    drawHUD(ctx, t);
    for (const [ht, a] of [[2.0, 0.16], [3.0, 0.1]]) {
      const k = 1 - prog(t, ht, ht + 0.25);
      if (t >= ht && k > 0) { ctx.fillStyle = `rgba(255,220,190,${a * k * k})`; ctx.fillRect(0, 0, W, H); }
    }
  }

  // ---------- fase B: logotipo + chamada ----------
  function satAngleB(t) {
    const L = LAY.logo, p = prog(t, TL.logo.orbit[0], TL.logo.orbit[1]);
    return L.aDock - TL.logo.turns * TAU * (1 - E.outCubic(p));
  }
  function drawAccent(ctx, x, y, m, r0, A) {
    const w = lerp(r0 * 2, A.w, m), h = lerp(r0 * 2, A.h, m), rad = lerp(r0, A.w * 0.32, m);
    ctx.save(); ctx.translate(x, y); ctx.rotate(A.rot * m);
    ctx.fillStyle = COL.sig; rrect(ctx, -w / 2, -h / 2, w, h, rad); ctx.fill();
    ctx.restore();
  }
  function phaseB(ctx, t) {
    const L = LAY.logo, el = L.ell;
    ctx.fillStyle = COL.bg; ctx.fillRect(0, 0, W, H);
    drawStars(ctx, t, W / 2, H / 2, W * 0.75, H * 0.62, 0.5, 0.04 * (t - 8));
    const mv = E.inOutExpo(prog(t, TL.cta.move[0], TL.cta.move[1]));
    const gy = -175 * mv;
    // horizonte planetário (cartela final)
    const hz = E.outCubic(prog(t, 12.0, 13.3));
    if (hz > 0) {
      const R = 1500, hcx = W / 2, hcy = H + 1330 + 260 * (1 - hz);
      let g = ctx.createRadialGradient(hcx, hcy, R - 40, hcx, hcy, R + 260);
      g.addColorStop(0, rgba(COL.sig, 0)); g.addColorStop(0.13, rgba(COL.sig, 0.45 * hz)); g.addColorStop(0.3, rgba('#FF8A4C', 0.16 * hz)); g.addColorStop(1, rgba(COL.sig, 0));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(hcx, hcy, R + 260, 0, TAU); ctx.fill();
      ctx.fillStyle = '#07080E'; ctx.beginPath(); ctx.arc(hcx, hcy, R, 0, TAU); ctx.fill();
      g = ctx.createRadialGradient(hcx, hcy, R - 120, hcx, hcy, R);
      g.addColorStop(0, rgba(COL.cool, 0)); g.addColorStop(1, rgba(COL.cool, 0.22 * hz));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(hcx, hcy, R, 0, TAU); ctx.fill();
      ctx.strokeStyle = rgba('#FFC9A8', 0.8 * hz); ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(hcx, hcy, R, 0, TAU); ctx.stroke();
    }
    ctx.save(); ctx.translate(0, gy);
    glow(ctx, W / 2, L.oCy, 620, COL.sig, 0.09 + 0.03 * Math.sin(t * 2));
    // onda de choque
    const sp = prog(t, 8.0, 8.9);
    if (sp > 0 && sp < 1) {
      ctx.strokeStyle = rgba(COL.sig, 0.8 * (1 - sp)); ctx.lineWidth = 10 * (1 - sp) + 1;
      ctx.beginPath(); ctx.arc(L.oCx, L.oCy, lerp(L.capH * 0.6, 1100, E.outCubic(sp)), 0, TAU); ctx.stroke();
    }
    // órbita traçada a partir do ponto de pouso
    const op = E.inOutCubic(prog(t, 8.1, 9.05));
    const paths = orbitPaths(el.cx, el.cy, el.rx, el.ry, el.rot, L.aDock + 0.0001, op);
    ctx.lineWidth = 2.2;
    ctx.strokeStyle = rgba(COL.ink, 0.22); ctx.stroke(paths.back);
    ctx.strokeStyle = rgba(COL.ink, 0.55); ctx.stroke(paths.front);
    // "O" chegando em zoom
    const z = E.outExpo(prog(t, TL.logo.ringZoom[0], TL.logo.ringZoom[1]));
    const sc = lerp(9, 1, z);
    ctx.font = L.font; ctx.textBaseline = 'alphabetic'; ctx.textAlign = 'left';
    ctx.save(); ctx.translate(L.oCx, L.oCy); ctx.scale(sc, sc); ctx.translate(-L.oCx, -L.oCy);
    ctx.fillStyle = COL.ink; ctx.fillText('O', L.x0, L.yB);
    ctx.restore();
    // RBITA sai de trás do O
    ctx.save(); ctx.beginPath(); ctx.rect(L.oR + 2, 0, W, H); ctx.clip();
    for (let i = 1; i < L.word.length; i++) {
      const st = TL.logo.letters + (i - 1) * TL.logo.letterStagger;
      const p = E.outExpo(prog(t, st, st + 0.6));
      if (p <= 0) continue;
      ctx.globalAlpha = clamp(p * 1.5);
      ctx.fillStyle = COL.ink;
      ctx.fillText(L.word[i], L.x0 + L.offs[i] - (1 - p) * 140, L.yB);
    }
    ctx.restore(); ctx.globalAlpha = 1;
    // satélite que vira o acento agudo
    const o0 = TL.logo.orbit[0], o1 = TL.logo.orbit[1];
    if (t >= o0) {
      const a = satAngleB(t);
      const pt = ellPt(el.cx, el.cy, el.rx, el.ry, el.rot, a);
      const m = E.inOutCubic(prog(t, o1 - 0.1, o1 + 0.12));
      const back = Math.sin(a) < 0 && m < 1;
      const r0 = L.capH * 0.085 * (back ? 0.85 : 1.1);
      const pos = m > 0 ? [lerp(pt[0], L.acc.x, m), lerp(pt[1], L.acc.y, m)] : pt;
      if (t < o1 + 0.2) {
        const trailA = 1 - prog(t, o1 - 0.05, o1 + 0.2);
        for (let k = 1; k <= 26; k++) {
          const ak = satAngleB(t - k * 0.012);
          const q = ellPt(el.cx, el.cy, el.rx, el.ry, el.rot, ak);
          ctx.fillStyle = rgba(COL.sig, 0.5 * trailA * (1 - k / 26));
          ctx.beginPath(); ctx.arc(q[0], q[1], r0 * (1 - k / 30), 0, TAU); ctx.fill();
        }
      }
      const dockFlash = prog(t, o1, o1 + 0.05) * (1 - prog(t, o1 + 0.05, o1 + 0.7));
      glow(ctx, pos[0], pos[1], r0 * 8 * (1 + dockFlash * 2), COL.sig, 0.5 + dockFlash * 0.5);
      drawAccent(ctx, pos[0], pos[1], m, r0, L.acc);
      const sh = prog(t, 15.0, 15.25) * (1 - prog(t, 15.25, 15.8));
      if (sh > 0) glow(ctx, L.acc.x, L.acc.y, 160, '#FFE9D2', 0.6 * sh);
    }
    // pequena lua contínua
    const ml = prog(t, 9.3, 9.8);
    if (ml > 0) {
      const a = L.aDock + Math.PI * 0.9 + (t - 9.3) * 0.85;
      const q = ellPt(el.cx, el.cy, el.rx, el.ry, el.rot, a);
      const fr = Math.sin(a) > 0 ? 1 : 0.6;
      glow(ctx, q[0], q[1], 28, COL.ink, 0.35 * ml);
      ctx.fillStyle = rgba(COL.ink, 0.9 * ml * fr); ctx.beginPath(); ctx.arc(q[0], q[1], 5 * fr + 1, 0, TAU); ctx.fill();
    }
    // linha de apoio digitada
    const t0 = TL.logo.tagline, cd = TL.logo.charDur;
    let n = 0, cursor = null, typing = false;
    ctx.font = '500 56px "Space Grotesk"'; ctx.textAlign = 'left';
    for (const ln of L.tag) {
      const chars = [...ln.text], x = W / 2 - ln.w / 2;
      let shown = '';
      for (const ch of chars) { if (t >= t0 + n * cd) shown += ch; n++; }
      if (shown.length) {
        ctx.fillStyle = rgba(COL.ink, 0.86); ctx.fillText(shown, x, ln.y);
        cursor = [x + ctx.measureText(shown).width + 8, ln.y];
      }
      if (shown.length < chars.length) { typing = true; break; }
    }
    const curA = prog(t, t0, t0 + 0.05) * (1 - prog(t, 11.6, 11.8));
    if (cursor && curA > 0 && (typing || Math.floor(t * 4) % 2 === 0)) {
      ctx.fillStyle = rgba(COL.sig, curA); ctx.fillRect(cursor[0], cursor[1] - 42, 24, 48);
    }
    ctx.restore();
    if (t >= TL.cta.start) drawCTA(ctx, t);
    const f = 1 - prog(t, 8.0, 8.35);
    if (f > 0) { ctx.fillStyle = `rgba(255,240,224,${0.9 * f * f})`; ctx.fillRect(0, 0, W, H); }
    const f2 = 1 - prog(t, 12.0, 12.2);
    if (t >= 12.0 && f2 > 0) { ctx.fillStyle = `rgba(255,220,190,${0.1 * f2})`; ctx.fillRect(0, 0, W, H); }
  }
  function drawCTA(ctx, t) {
    const L = LAY.logo;
    const pw = 840, ph = 132, px = W / 2 - pw / 2, py = 1268 - ph / 2;
    const tr = E.inOutCubic(prog(t, TL.cta.trace[0], TL.cta.trace[1]));
    const fl = E.inOutExpo(prog(t, TL.cta.fill[0], TL.cta.fill[1]));
    const appear = E.outExpo(prog(t, 12.05, 12.6));
    ctx.save();
    ctx.translate(0, (1 - appear) * 60);
    const per = 2 * (pw - ph) + Math.PI * ph;
    if (tr > 0) {
      ctx.setLineDash([per * tr, per]); ctx.lineDashOffset = 0;
      ctx.strokeStyle = rgba(COL.ink, 0.9); ctx.lineWidth = 3;
      rrect(ctx, px, py, pw, ph, ph / 2); ctx.stroke(); ctx.setLineDash([]);
    }
    const text = TL.copy.cta;
    ctx.font = '600 50px "Space Grotesk"'; ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
    const tx = W / 2 - 40 - L.ctaW / 2, ty = py + ph / 2 + 2;
    const tp = E.outExpo(prog(t, 12.2, 12.75));
    let nud = 0;
    for (const n of TL.cta.nudges) if (t >= n) nud += Math.sin(Math.min(1, (t - n) / 0.45) * Math.PI) * Math.exp(-(t - n) * 2);
    const arrow = (col) => {
      const ax = px + pw - 96 + nud * 18, ay = py + ph / 2;
      ctx.strokeStyle = col; ctx.lineWidth = 5; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      ctx.beginPath(); ctx.moveTo(ax - 26, ay); ctx.lineTo(ax + 22, ay); ctx.moveTo(ax + 4, ay - 18); ctx.lineTo(ax + 22, ay); ctx.lineTo(ax + 4, ay + 18); ctx.stroke();
    };
    const content = (col) => {
      ctx.save(); ctx.beginPath(); ctx.rect(px, py + 10, pw, ph - 20); ctx.clip();
      ctx.fillStyle = col; ctx.fillText(text, tx, ty + (1 - tp) * 70);
      ctx.restore();
      if (tp > 0) { ctx.save(); ctx.globalAlpha = tp; arrow(col); ctx.restore(); }
    };
    content(COL.ink);
    if (fl > 0) {
      ctx.save(); ctx.beginPath(); ctx.rect(px - 4, py - 4, (pw + 8) * fl, ph + 8); ctx.clip();
      ctx.fillStyle = COL.sig; rrect(ctx, px, py, pw, ph, ph / 2); ctx.fill();
      content('#140806');
      const sh = prog(t, TL.cta.shine, TL.cta.shine + 0.6);
      if (sh > 0 && sh < 1) {
        rrect(ctx, px, py, pw, ph, ph / 2); ctx.clip();
        const sx = lerp(px - 200, px + pw + 200, E.inOutSine(sh));
        const g = ctx.createLinearGradient(sx - 120, 0, sx + 120, 0);
        g.addColorStop(0, 'rgba(255,240,220,0)'); g.addColorStop(0.5, 'rgba(255,240,220,0.45)'); g.addColorStop(1, 'rgba(255,240,220,0)');
        ctx.fillStyle = g; ctx.fillRect(sx - 120, py, 240, ph);
      }
      ctx.restore();
    }
    // brilho da varredura de preenchimento
    if (fl > 0 && fl < 1) glow(ctx, px + pw * fl, py + ph / 2, 240, '#FFD2B8', 0.5 * Math.sin(fl * Math.PI));
    ctx.restore();
  }

  function drawScene(ctx, t) {
    ctx.save();
    ctx.textAlign = 'left'; ctx.letterSpacing = '0px'; ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    if (t < TL.logo.hit) phaseA(ctx, t); else phaseB(ctx, t);
    ctx.restore();
  }

  // ---------- desfoque de movimento (obturador) + pós-produção ----------
  function blurSpec(t) {
    if (t >= TL.contract[0] && t <= TL.contract[1]) return [6, 0.5];
    for (const s of TL.snaps) if (t >= s - 0.02 && t <= s + TL.snapDur) return [6, 0.5];
    if (t >= TL.rush[0] && t < TL.rush[1]) return [12, 1.0];
    if (t >= TL.logo.ringZoom[0] && t < TL.logo.ringZoom[1] + 0.05) return [8, 0.6];
    if (t >= TL.logo.orbit[0] && t < TL.logo.orbit[1]) return [5, 0.5];
    if (t >= TL.cta.move[0] && t < TL.cta.move[1]) return [4, 0.5];
    return [1, 0];
  }
  let main, mctx, acc, actx, tmp, tctx, bloom, bctx;
  const GRAIN = [];
  function setup(canvas) {
    main = canvas; mctx = main.getContext('2d');
    const mk = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return [c, c.getContext('2d')]; };
    [acc, actx] = mk(W, H); [tmp, tctx] = mk(W, H); [bloom, bctx] = mk(270, 480);
    for (let k = 0; k < 8; k++) {
      const [g, gc] = mk(540, 960); const id = gc.createImageData(540, 960); const r = rng(100 + k);
      for (let i = 0; i < id.data.length; i += 4) { const v = 128 + (r() + r() + r() - 1.5) * 120; id.data[i] = id.data[i + 1] = id.data[i + 2] = v; id.data[i + 3] = 255; }
      gc.putImageData(id, 0, 0); GRAIN.push(g);
    }
  }
  function renderFrame(t, opts = {}) {
    const fps = TL.fps;
    const [n, sh] = opts.fast ? [1, 0] : blurSpec(t);
    actx.globalAlpha = 1;
    if (n === 1) drawScene(actx, t);
    else {
      for (let k = 0; k < n; k++) {
        let ts = t + (k / (n - 1) - 0.5) * sh / fps;
        if (t < TL.logo.hit) ts = Math.min(ts, TL.logo.hit - 1e-4); else ts = Math.max(ts, TL.logo.hit);
        drawScene(tctx, ts);
        actx.globalAlpha = 1 / (k + 1); actx.drawImage(tmp, 0, 0);
      }
      actx.globalAlpha = 1;
    }
    mctx.save();
    mctx.globalCompositeOperation = 'source-over'; mctx.globalAlpha = 1; mctx.drawImage(acc, 0, 0);
    if (!opts.fast) {
      bctx.save(); bctx.clearRect(0, 0, 270, 480); bctx.filter = 'brightness(0.95) contrast(2.6) blur(7px)'; bctx.drawImage(acc, 0, 0, 270, 480); bctx.restore();
      mctx.globalCompositeOperation = 'screen'; mctx.globalAlpha = 0.42; mctx.drawImage(bloom, 0, 0, W, H);
    }
    mctx.globalCompositeOperation = 'source-over'; mctx.globalAlpha = 1;
    const g = mctx.createRadialGradient(W / 2, H / 2, H * 0.28, W / 2, H / 2, H * 0.72);
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,0.55)');
    mctx.fillStyle = g; mctx.fillRect(0, 0, W, H);
    const gi = Math.floor(t * fps + 0.5) % GRAIN.length;
    mctx.globalCompositeOperation = 'overlay'; mctx.globalAlpha = 0.16; mctx.drawImage(GRAIN[gi], 0, 0, W, H);
    mctx.globalCompositeOperation = 'lighter'; mctx.globalAlpha = 0.022; mctx.drawImage(GRAIN[(gi + 3) % GRAIN.length], 0, 0, W, H);
    mctx.restore();
  }

  const ready = (async () => {
    await Promise.all([
      document.fonts.load('700 100px Unbounded'), document.fonts.load('800 100px Unbounded'),
      document.fonts.load('500 56px "Space Grotesk"'), document.fonts.load('600 50px "Space Grotesk"'),
      document.fonts.load('400 24px "Space Mono"'), document.fonts.load('700 24px "Space Mono"'),
    ]);
    await document.fonts.ready;
    setup(document.getElementById('c'));
    computeLayout();
    return true;
  })();

  window.ORBITA = {
    ready, renderFrame, W, H,
    layout: () => LAY,
    frameData: (t) => { renderFrame(t); return main.toDataURL('image/png'); },
  };
})();
