// Renderiza os quadros do anúncio com Chromium headless (Playwright).
// Uso:
//   node src/render.js                       -> todos os quadros em build/frames/f_0000.png ...
//   node src/render.js --stills 1.2,3.5,9    -> quadros soltos em build/stills/ (revisão)
//   node src/render.js --workers 6
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const args = process.argv.slice(2);
const opt = (k, d) => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : d; };

(async () => {
  const tlSrc = fs.readFileSync(path.join(__dirname, 'timeline.js'), 'utf8');
  const TL = JSON.parse(tlSrc.slice(tlSrc.indexOf('{'), tlSrc.lastIndexOf('}') + 1));
  const stills = opt('--stills', null);
  const workers = +opt('--workers', 6);
  let jobs, outDir, name;
  if (stills) {
    outDir = path.join(ROOT, 'build', 'stills');
    jobs = stills.split(',').map(Number);
    name = (t) => `s_${t.toFixed(3)}.png`;
  } else {
    outDir = path.join(ROOT, 'build', 'frames');
    const n = Math.round(TL.duration * TL.fps);
    jobs = [...Array(n).keys()].map(i => i / TL.fps);
    name = (t) => `f_${String(Math.round(t * TL.fps)).padStart(4, '0')}.png`;
  }
  fs.mkdirSync(outDir, { recursive: true });
  const browser = await chromium.launch();
  const url = 'file:///' + path.join(__dirname, 'orbita.html').replace(/\\/g, '/');
  let next = 0, done = 0;
  const t0 = Date.now();
  async function worker(id) {
    const page = await browser.newPage({ viewport: { width: 1080, height: 1920 }, deviceScaleFactor: 1 });
    page.on('pageerror', e => console.error('pageerror', e));
    page.on('console', m => { if (m.type() === 'error') console.error('console', m.text()); });
    await page.goto(url);
    await page.evaluate(() => window.ORBITA.ready);
    if (id === 0) fs.writeFileSync(path.join(ROOT, 'build', 'layout.json'), JSON.stringify(await page.evaluate(() => window.ORBITA.layout()), null, 2));
    while (next < jobs.length) {
      const t = jobs[next++];
      const data = await page.evaluate((tt) => window.ORBITA.frameData(tt), t);
      fs.writeFileSync(path.join(outDir, name(t)), Buffer.from(data.split(',')[1], 'base64'));
      done++;
      if (done % 30 === 0 || done === jobs.length) process.stdout.write(`\r${done}/${jobs.length} quadros  ${((Date.now() - t0) / 1000).toFixed(0)}s`);
    }
    await page.close();
  }
  fs.mkdirSync(path.join(ROOT, 'build'), { recursive: true });
  await Promise.all([...Array(Math.min(workers, jobs.length)).keys()].map(worker));
  await browser.close();
  console.log('\nok ->', outDir);
})();
