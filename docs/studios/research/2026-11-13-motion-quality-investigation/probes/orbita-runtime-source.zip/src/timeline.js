window.TL = {
  "fps": 30,
  "duration": 16.0,
  "bpm": 120,
  "copy": {
    "headline": ["O futuro", "cabe num", "curta."],
    "brand": "ÓRBITA",
    "tagline": ["mostra de curtas de", "ficção científica"],
    "cta": "Confira a programação."
  },
  "headline": { "starts": [0.9, 2.0, 3.0], "stagger": 0.035, "charDur": 0.55, "exit": 4.0 },
  "contract": [2.0, 2.85],
  "recenter": [4.0, 4.5],
  "snaps": [4.5, 5.0, 5.5, 6.0, 6.25, 6.5, 6.75, 7.0, 7.25, 7.5],
  "snapDur": 0.16,
  "rush": [7.5, 8.0],
  "logo": {
    "hit": 8.0,
    "ringZoom": [8.0, 8.55],
    "orbit": [8.15, 9.2],
    "turns": 1.5,
    "letters": 8.5,
    "letterStagger": 0.07,
    "tagline": 10.0,
    "charDur": 0.03
  },
  "cta": { "start": 12.0, "move": [12.0, 12.6], "trace": [12.05, 12.45], "fill": [12.35, 12.8], "nudges": [13.0, 14.0, 15.0], "shine": 14.5 },
  "hits": { "medium": [2.0, 3.0, 12.0], "big": [8.0] }
};
